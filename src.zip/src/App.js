import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import RecipeApp from './components/RecipeApp';

function App() {
  return (
    <div className="App">
      <RecipeApp/>
    </div>
  );
}

export default App;
