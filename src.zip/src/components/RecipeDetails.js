import React from 'react'

function RecipeDetails({oneItem}) {
    
    console.log("oneitem",oneItem);
    return (
        <div>
            
            
        </div>
    )
}

export default RecipeDetails

